# NeoCDT-IS02
Proyecto de Ingeniería de Software II — Módulo Bancario “NeoCDT” (Login + CRUD de SolicitudesCDT).
